<!doctype html>
<style>
#error{
    width:92%;
    margin:0px auto;
    padding:10px;
    border:1px solid #a94442;
    background:#f2dede;
    border-radius:5px;
    text-align:left;

}
.variablecolor{
color:red;}
</style>
<?php
  $errors = array();
  include('config.php');
  

  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "fyp";

  $conn = new mysqli($servername, $username, $password, $dbname);
   
    // Check connection
    if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
      }
    
      $sql = "SELECT * FROM userdetail";
      $result = mysqli_query($conn, $sql);
    
$result=$conn->query($sql);

?>
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">
<link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<style>
    body{ font: 14px sans-serif; }
    .wrapper{ width: 360px; padding: 20px; }
</style>
<title>Dormitory Management System</title>

<!-- Bootstrap core CSS -->
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<!-- Additional CSS Files -->
<link rel="stylesheet" href="assets/css/fontawesome.css">
<link rel="stylesheet" href="assets/css/templatemo-grad-school.css">
<link rel="stylesheet" href="assets/css/owl.css">
<link rel="stylesheet" href="assets/css/lightbox.css">

</head>

<body>
<!--header-->
<header class="main-header clearfix" role="header">
    <div class="logo">
      <a href="homePage.php"><em>Dorm</em> Sys</a>
    </div>
    <a href="#menu" class="menu-link"><i class="fa fa-bars"></i></a>
    <nav id="menu" class="main-nav" role="navigation">
      <ul class="main-menu">
        <!-- <li><a href="index.php">Home</a></li> -->
          <li><a href="accountPage.php">Account</a>
          <!-- <ul class="sub-menu">
            <li><a href="#section2">Register</a></li>
            <li><a href="#section3">Login</a></li>
            <li><a href="#section3">Account Details</a></li>
            <li><a href="#section4">Generate User Listing</a></li>
          </ul> -->
        </li>
        <li><a href="roomPage.php">Room</a></li>
        <li><a href="keyPage.php">Key</a></li>
        <li><a href="cardPage.php">Card</a></li>
        <li><a href="announcementPage.php">Announcement</a></li>
        <li><a href="feedbackPage.php">Feedback</a></li>
        <li><a href="faultPage.php">Fault</a></li>
        <li><a href="reportPage.php">Report</a></li>
        <li><a href="logout.php" style="background-color:red;">Log Out</a></li>
        <!-- <li><a href="#section5">Video</a></li> -->
      </ul>
    </nav>
  </header>

<br>
<br>
<br>
<br>
<h2 style="padding-left:200px; padding-top:50px; color:white;"><strong>View Account</strong></h2>
<br><br>
<body style="background-image:url(assets/images/banner.jpg);">

<div class="container">
	    <div class="row">
			
		    <table class="table table-hover table-striped">
		        <thead>
		        <tr class="thead-dark">
		            <th style="color:white;">ID</th>
		            <th style="color:white;">Date of Stay</th>
		            <th style="color:white;">Type</th>
					      <th style="color:white;">Room ID</th>
					      <th style="color:white;">Key ID</th>
                <th style="color:white;">Card ID</th>
                <th style="color:white;">Status</th>
		        </tr>
		    </thead>
		        <tbody>
		            <?php
	if($result->num_rows > 0){
		while($row=$result->fetch_assoc()){
            $ID=$row['ID'];
            $dateOfStay=$row['dateOfStay'];  
            $type=$row['type'];
            $roomID=$row['roomID'];
            $keyID=$row['keyID'];
            $cardID=$row['cardID'];
            $status=$row['status'];
	//display result​
    echo "<td><input type='text' name='price' size='10' value='$ID'></td>";
    echo "<td><input type='text' name='price' size='10' value='$dateOfStay' onchange='updatePrice($dateOfStay, $ID)'></td>";
    echo "<td><input type='text' name='price' size='10' value='$type' onchange='updatePrice($type, this.value)'></td>";
    echo "<td><input type='text' name='price' size='10' value='$roomID' onchange='updatePrice($roomID, this.value)'></td>";
    echo "<td><input type='text' name='price' size='10' value='$keyID' onchange='updatePrice($keyID, this.value)'></td>";
    echo "<td><input type='text' name='price' size='10' value='$cardID' onchange='updatePrice($cardID, this.value)'></td>";
    echo "<td><input type='text' name='price' size='10' value='$status' onchange='updatePrice($status, this.value)'></td>";
    echo "</tr>";

}//end while loop​
	
}//end if statement
					?>	        
		        </tbody>
		    </table>
	</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <script>
    function updatePrice($ID, $dateOfStay){
    if($ID=='' && $dateOfStay==''){
        // do nothing
        // console.log(this.responseText);
    }
    else{
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){
                // do something here;
                //alert(this.responseText);
            }
        };
        xmlhttp.open('GET', 'test2.php?ID='+$ID+'&dateOfStay='+$dateOfStay, true);
        xmlhttp.send();
    }
}
</script>
</body>
</html>