<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <style>
        @media screen and (max-width: 500px) {
          #a{margin-bottom:25px;}
        }
    </style>
    <title>Dormitory Management System--Key Page</title>
    
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-grad-school.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/lightbox.css">
		<script>
    function ConfirmLogout() {
	      return confirm("Are you sure you want to logout?");
    }
    </script>
  </head>

<body>
  <!--header-->
  <header class="main-header clearfix" role="header">
    <div class="logo">
      <a href="#"><em>Dorm</em> Sys</a>
    </div>
    <a href="#menu" class="menu-link"><i class="fa fa-bars"></i></a>
    <nav id="menu" class="main-nav" role="navigation">
      <ul class="main-menu">
        <!-- <li><a href="index.php">Home</a></li> -->
          <li><a href="accountPage.php">Account</a>
          <!-- <ul class="sub-menu">
            <li><a href="#section2">Register</a></li>
            <li><a href="#section3">Login</a></li>
            <li><a href="#section3">Account Details</a></li>
            <li><a href="#section4">Generate User Listing</a></li>
          </ul> -->
        </li>
        <li><a href="facilityPage.php">Facility</a>
        <li><a href="roomPage.php">Room</a></li>
        <li><a href="keyPage.php">Key</a></li>
        <li><a href="cardPage.php">Card</a></li>
        <li><a href="announcementPage.php">Announcement</a></li>
        <li><a href="feedbackPage.php">Feedback</a></li>
        <li><a href="faultPage.php">Fault</a></li>
        <li><a href="reportPage.php">Report</a></li>
        <li><a href="logout.php" style="background-color:red;" onclick="return ConfirmLogout()">Log Out</a></li>
        <!-- <li><a href="#section5">Video</a></li> -->
      </ul>
    </nav>
  </header>
  
    <!-- Main Page Start-->
  <section class="section main-banner" id="top" data-section="section1" style="margin-top: -72px;">
      <video autoplay muted loop id="bg-video">
          <source src="assets/images/video1.mp4" type="video/mp4" />
      </video>

      <div class="video-overlay header-text">
          <div class="caption">
              <!-- <h6 style= color:yellow;>Dormitory Management System</h6> -->
              <h2><em>Key</em></br></br></h2>
              <!-- <h3 style= color:white;>Reliable and Informative System</h3></br> -->
              <div class="main-button">
                  <div class="scroll-to-section"><a id="a" href="viewKey.php">View Key Details</a>
                  <a href="searchKey.php" style="margin-left:50px; margin-right:50px">Search Key</a></div>
                </div>
          </div>
      </div>
  </section>
  <!-- Main Page End-->


  <section class="features">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-12">
          <div class="features-post">
            <div class="features-content">
              <div class="content-show">
                <h4><a href="insertKey.php" style="font-size:18px;">Add Details</a></h4>
              </div>
              <!-- <div class="content-hide">
                <p>To computerized all the residents and facilities details in a convenient way.</p>
            </div> -->
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-12">
          <div class="features-post second-features">
            <div class="features-content">
            <div class="content-show">
                <h4><a href="modifyKey.php" style="font-size:18px;">Edit Details</a></h4>
              </div>
              <!-- <div class="content-hide">
                <p>To check personal details and receive annoucement.</p>
            </div> -->
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-12">
          <div class="features-post third-features">
            <div class="features-content">
            <div class="content-show">
                <h4><a href="removeKey.php" style="font-size:18px;">Remove Details</a></h4>
              </div>
              <!-- <div class="content-hide">
                <p>Have a complete dormitory management system to manage details.</p>
            </div> -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <footer>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <p><i class="fa fa-copyright"></i> Dormitory Management System<a href="#" rel="sponsored" target="_parent"></a></p>
        </div>
      </div>
    </div>
  </footer>

  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script src="assets/js/isotope.min.js"></script>
    <script src="assets/js/owl-carousel.js"></script>
    <script src="assets/js/lightbox.js"></script>
    <script src="assets/js/tabs.js"></script>
    <script src="assets/js/video.js"></script>
    <script src="assets/js/slick-slider.js"></script>
    <script src="assets/js/custom.js"></script>
    <script>
        //according to loftblog tut
        $('.nav li:first').addClass('active');

        var showSection = function showSection(section, isAnimate) {
          var
          direction = section.replace(/#/, ''),
          reqSection = $('.section').filter('[data-section="' + direction + '"]'),
          reqSectionPos = reqSection.offset().top - 0;

          if (isAnimate) {
            $('body, html').animate({
              scrollTop: reqSectionPos },
            800);
          } else {
            $('body, html').scrollTop(reqSectionPos);
          }

        };

        var checkSection = function checkSection() {
          $('.section').each(function () {
            var
            $this = $(this),
            topEdge = $this.offset().top - 80,
            bottomEdge = topEdge + $this.height(),
            wScroll = $(window).scrollTop();
            if (topEdge < wScroll && bottomEdge > wScroll) {
              var
              currentId = $this.data('section'),
              reqLink = $('a').filter('[href*=\\#' + currentId + ']');
              reqLink.closest('li').addClass('active').
              siblings().removeClass('active');
            }
          });
        };

        // $('.main-menu, .scroll-to-section').on('click', 'a', function (e) {
        //   if($(e.target).hasClass('external')) {
        //     return;
        //   }
        //   e.preventDefault();
        //   $('#menu').removeClass('active');
        //   showSection($(this).attr('href'), true);
        // });

        $(window).scroll(function () {
          checkSection();
        });
    </script>
</body>
</html>