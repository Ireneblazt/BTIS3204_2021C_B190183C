<?php
  $errors = array();
  
  include('config.php');
  

  $servername = "localhost";
  $username = "root";
  $password1 = "";
  $dbname = "fyp";

  $conn = new mysqli($servername, $username, $password1, $dbname);
   
    // Check connection
    if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
      }
      
      if(isset($_POST['update'])) // when click on Update button
      {
        $username=$_POST['username'];
        $password=$_POST['password'];
        $param_password = password_hash($password, PASSWORD_DEFAULT);
        $edit = mysqli_query($conn,"UPDATE username SET password = '$param_password' WHERE username='$username'");
  	        
            $result=$conn->query($edit);
            mysqli_close($conn); // Close connection
            header("location:resetPassword.php"); // redirects to all records page
            
        }


?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif; }
        .wrapper{ height: 734px; width: 360px; padding: 20px; margin-left:530px;}
        
        @media screen and (max-width: 500px) {
          .wrapper{ height: 694px; width: 360px; padding: 20px; margin-left:20px; margin-top:35px;}
        }
    </style>
    <title>Dormitory Management System</title>
    
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-grad-school.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/lightbox.css">
    <script>
    function Confirm() {
      return confirm("Are you sure to reset new password?");
    }
    function validateForm() {
        alert("Password Reset Successfully.");
        return true;
    }
    </script>
  </head>

<body>
  <!--header-->
  <header class="main-header clearfix" role="header">
    <div class="logo">
      <a href="#"><em>Dorm</em> Sys</a>
    </div>
    <a href="#menu" class="menu-link"><i class="fa fa-bars"></i></a>
    <nav id="menu" class="main-nav" role="navigation" style="overflow:hidden;">
      <ul class="main-menu">
        <li><a href="logout.php">Login</a></li>
        <!-- <li><a href="registrationPage.php">Register</a></li> -->
        <!-- <li class="has-submenu"><a href="#section2">Account</a>
          <ul class="sub-menu">
            <li><a href="#section2">Register</a></li>
            <li><a href="#section3">Login</a></li>
            <li><a href="#section3">Account Details</a></li>
            <li><a href="#section4">Generate User Listing</a></li>
          </ul>
        </li>
        <li><a href="#section4">Room</a></li>
        <li><a href="#section6">Key</a></li>
        <li><a href="#section6">Card</a></li>
        <li><a href="#section6">Announcement</a></li>
        <li><a href="#section6">Feedback</a></li>
        <li><a href="#section6">Fault</a></li>
        <li><a href="#section6">Report</a></li> -->
        <!-- <li><a href="#section5">Video</a></li> -->
      </ul>
    </nav>
  </header>

  <section class="section contact" data-section="section6">
  <div class="wrapper">
        <p style="color:yellow; margin-top:80px; margin-left:120px; font-size:25px;">Reset Password</p>
        </br>
        <form style="margin-left:60px;" method = "post" enctype="multipart/form-data"  onsubmit="return validateForm()">
    <div class="form-group">
            <label for="username"><h5 style="color:white;">Username</h5></label></br>
            <input type="text" class="form-control" id="username" name="username" required>
          </div>
          <div class="form-group">
            <label for="password1"><h5 style="color:white;"> Current Password</h5></label>
            <input type="password" class="form-control" id="password1" name="password1" required>
        </div>
        <div class="form-group">
            <label for="password"><h5 style="color:white;">Password</h5></label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <div class="form-group">
            <label for="password2"><h5 style="color:white;">Confirm Password</h5></label>
            <input type="password" class="form-control" id="password2" name="password2" required>
        </div>
        <br>
            <button type="submit" class="btn btn-primary"name="update" onclick="return Confirm()">Submit</button>
        </div>
        <br>
        <br>
    </form>
    </div>    
  </section>

  <footer>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <p><i class="fa fa-copyright"></i> Dormitory Management System<a href="#" rel="sponsored" target="_parent"></a></p>
        </div>
      </div>
    </div>
  </footer>

  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script src="assets/js/isotope.min.js"></script>
    <script src="assets/js/owl-carousel.js"></script>
    <script src="assets/js/lightbox.js"></script>
    <script src="assets/js/tabs.js"></script>
    <script src="assets/js/video.js"></script>
    <script src="assets/js/slick-slider.js"></script>
    <script src="assets/js/custom.js"></script>
    <script>
        //according to loftblog tut
        $('.nav li:first').addClass('active');

        var showSection = function showSection(section, isAnimate) {
          var
          direction = section.replace(/#/, ''),
          reqSection = $('.section').filter('[data-section="' + direction + '"]'),
          reqSectionPos = reqSection.offset().top - 0;

          if (isAnimate) {
            $('body, html').animate({
              scrollTop: reqSectionPos },
            800);
          } else {
            $('body, html').scrollTop(reqSectionPos);
          }

        };

        var checkSection = function checkSection() {
          $('.section').each(function () {
            var
            $this = $(this),
            topEdge = $this.offset().top - 80,
            bottomEdge = topEdge + $this.height(),
            wScroll = $(window).scrollTop();
            if (topEdge < wScroll && bottomEdge > wScroll) {
              var
              currentId = $this.data('section'),
              reqLink = $('a').filter('[href*=\\#' + currentId + ']');
              reqLink.closest('li').addClass('active').
              siblings().removeClass('active');
            }
          });
        };

        // $('.main-menu, .scroll-to-section').on('click', 'a', function (e) {
        //   if($(e.target).hasClass('external')) {
        //     return;
        //   }
        //   e.preventDefault();
        //   $('#menu').removeClass('active');
        //   showSection($(this).attr('href'), true);
        // });

        $(window).scroll(function () {
          checkSection();
        });
    </script>
</body>
</html>