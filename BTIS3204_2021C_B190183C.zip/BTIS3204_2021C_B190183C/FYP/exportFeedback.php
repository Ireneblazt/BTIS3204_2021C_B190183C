<?php  
//export.php  
$connect = mysqli_connect("localhost", "root", "", "fyp");
$output = '';
if(isset($_POST["export"]))
{
 $query = "SELECT * FROM feedbackdetail";
 $result = mysqli_query($connect, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
  <table class="table" bordered="1">  
  <tr>  
        <th>ID</th>  
        <th>Username</th>  
        <th>Respond ID</th>  
        <th>Topic</th>
        <th>Message</th>
  </tr>
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
                <tr>  
                    <td>'.$row["ID"].'</td>  
                    <td>'.$row["username"].'</td>  
                    <td>'.$row["respondID"].'</td>
                    <td>'.$row["topic"].'</td>  
                    <td>'.$row["message"].'</td>
                </tr>
   ';
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=FeedbackReport.xls');
  echo $output;
 }
}
?>
