<?php

include "config.php"; // Using database connection file here

$ID = $_GET['id']; // get id through query string

$del = mysqli_query($link,"DELETE FROM carddetail WHERE id = $ID"); // delete query

if($del)
{
    mysqli_close($link); // Close connection
    header("location:removeCard.php"); // redirects to all records page
    exit;	
}
else
{
    echo "Error deleting record"; // display error message if not delete
}
?>