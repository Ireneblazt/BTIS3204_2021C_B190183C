<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta name="description" content="JJ Lin">
		<meta name="keywords" content="JJ Lin, Wayne Lin Jun Jie, Lin Jun Jie, 林俊杰">
		<meta name="author" content="Soh Kian Seng">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>林俊杰</title>
		<link href="style.css" rel="stylesheet" />
		<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
		<link href="https://cdnjs.cloudflare.com/ajax/libs/fotorama/4.6.4/fotorama.css" rel="stylesheet">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/fotorama/4.6.4/fotorama.js"></script>
		<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
		<script src="script.js"></script>

	 <div class="topnav">
		<a href="Home.html">Home</a>
		<a href="Introduction.html">Account Details</a>
		<a href="Discography.html">Facility</a>
		<a href="Video.html">Room</a>
		<a href="LatestSong.html">Key</a>
		<a href="Form.html">Card</a>
		<a href="Links.html">Announcement</a>
		<a href="Author.html">Feedback</a>
		<a href="Documentations.html">Fault Report</a>
        <a href="Documentations.html">Report</a>
		<a></a>
		<a></a>
		<a href="login.php" style="color:cyan"><strong>Login</strong></a>
        <a href="register.php" style="color:cyan"><strong>Register</strong></a>
	    <a></a>
        <a href="#Documentations">
	   <marquee  onMouseout="this.scrollAmount=10" scrolldelay="20" scrollamount="2" direction="left" width="100%" height="20%">
       <a></a>
	   <a></a>
       <div class="div2">
	   <script>
var mydate=new Date()
var year=mydate.getYear()
if (year < 1000)
year+=1900
var day=mydate.getDay()
var month=mydate.getMonth()
var daym=mydate.getDate()
if (daym<10)
daym="0"+daym
var dayarray=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")
var montharray=new Array("January","February","March","April","May","June","July","August","September","October","November","December")
document.write("<small><font color='000000' face='Arial'><b>"+dayarray[day]+", "+montharray[month]+" "+daym+", "+year+"</b></font></small>")
</script>
<script language="JavaScript">
if (document.all||document.getElementById)
document.write('<span id="worldclock" style="font:bold 16px Arial;"></span><br />')

zone=0;
isitlocal=true;
ampm='';

function updateclock(z){
zone=z.options[z.selectedIndex].value;
isitlocal=(z.options[0].selected)?true:false;
}

</script>
</div>
</marquee></a>
	</div>
	<a><div class="script1">
	<script 
  type="text/JavaScript" 
  language="JavaScript">
<!-- 
//
// format date as dd-mmm-yy
// example: 12-Jan-99
//
function date_ddmmmyy(date)
{
  var d = date.getDate();
  var m = date.getMonth() + 1;
  var y = date.getYear();

  // handle different year values 
  // returned by IE and NS in 
  // the year 2000.
  if(y >= 2000)
  {
    y -= 2000;
  }
  if(y >= 100)
  {
    y -= 100;
  }

  // could use splitString() here 
  // but the following method is 
  // more compatible
  var mmm = 
    ( 1==m)?'Jan':( 2==m)?'Feb':(3==m)?'Mar':
    ( 4==m)?'Apr':( 5==m)?'May':(6==m)?'Jun':
    ( 7==m)?'Jul':( 8==m)?'Aug':(9==m)?'Sep':
    (10==m)?'Oct':(11==m)?'Nov':'Dec';

  return "" +
    (d<10?"0"+d:d) + "-" +
    mmm + "-" +
    (y<10?"0"+y:y);
}


//
// get last modified date of the 
// current document.
//
function date_lastmodified()
{
  var lmd = document.lastModified;
  var s   = "Unknown";
  var d1;

  // check if we have a valid date
  // before proceeding
  if(0 != (d1=Date.parse(lmd)))
  {
    s = "" + date_ddmmmyy(new Date(d1));
  }

  return s;
}

//
// finally display the last modified date
// as DD-MMM-YY
//
document.write( 
  "This page was updated on " + 
  date_lastmodified() );

// -->
</script>
	</div></a>
	</div>
	
	
	<body class="background-title1">
	</br>
	<div class="position1">
	<!-- <div class="fotorama" data-autoplay="true" align="center">
	<img src="ljj12.jpg" width="2000" height="400">
	<img src="ljj13.jpg" width="400" height="400">
	</div>
	</div>
	
	<hr width="100%"/>
	<nav class="position">
	<a href="Home.html"><div class="glow-on-hover">Home</br></div></a>
	<a href="Introduction.html"><div class="glow-on-hover">Introduction</br><a href="Page2.html"></div></a>
	<a href="Discography.html"><div class="glow-on-hover">Discography</br></div></a>
	<a href="Video.html"><div class="glow-on-hover">Video</br></div></a>
	<a href="LatestSong.html"><div class="glow-on-hover">Latest Song</br></div></a>
	<a href="Form.html"><div class="glow-on-hover">Form</br></div></a>
	<a href="Links.html"><div class="glow-on-hover">Links</br></div></a>
	<a href="Author.html"><div class="glow-on-hover">Author</br></div></a>
	<a href="Documentations.html"><div class="glow-on-hover">Documentations</br></div></a>
	</nav>

	<div class="div1">
	<div align="center">
	<a href="https://www.facebook.com/JJLin/" target="new" class="fa fa-facebook"></a>
	<a href="https://www.youtube.com/user/jjlin" target="new" class="fa fa-youtube"></a>
	<a href="https://www.instagram.com/jjlin/" target="new" class="fa fa-instagram"></a>
	</div>
	<hr width="90%" align="center" noshade>
	<div class="fotorama" data-autoplay="true" align="center">
	<img src="ljj1.jpg" width="400" height="400">
	<img src="ljj4.jpg" width="400" height="400">
	<img src="ljj6.jpg" width="400" height="400">
	<img src="ljj7.jpg" width="400" height="400">
	<img src="ljj8.jpg" width="400" height="400">
	<img src="ljj9.jpg" width="400" height="400">
	</div>
	</div>
	
	<div align="center">
	<h2>Copyright notice:</h2>
	<p>The gif is my creative.</p>
	
	<h2>Acknowledgements to:</h2>
	<p>JavaScript Kit : Providing free copyright, pictures and related information.</p>
	
	<h2>For more information, please contact us :</h2>
		<p>WebMaster Name:Soh Kian Seng<br>ID:B190183C<br><a href="mailto:Rickysoh1998@icloud.com"><u>Rickysoh1998@icloud.com</u></a></p>
		
		<p>WebMaster Name:Tan Chi Xian<br>ID:B190157C<br><a href="mailto:Xianchitan@gmail.com"><u>Xianchitan@gmail.com</u></a></p>

		<p>WebMaster Name:Soh Joen Shiuan<br>ID:B190190C<br><a href="mailto:Sohjoenshiuan@icloud.com"><u>Sohjoenshiuan@icloud.com</u></a></p>
	</div>
		
	
	<div class="footer">
		© Copyright 2019 BoSE-19C Group Project Teams. All right reserved.</br>
		All text, ideas and graphics found at this site are copyrighted by the author and may not used for any purpose other than those specified or allowed by the author.</br>
	Website design by SUC 2019 BoSE-19C  Student. -->
	</div>
	</body>

</html>