<!doctype html>
<style>
#error{
    width:92%;
    margin:0px auto;
    padding:10px;
    border:1px solid #a94442;
    background:#f2dede;
    border-radius:5px;
    text-align:left;

}
.variablecolor{
color:red;}
</style>
<?php
  $errors = array();
  include('config.php');
  

  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "fyp";

  $conn = new mysqli($servername, $username, $password, $dbname);
   
    // Check connection
    if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
      }
    
      $sql = "SELECT * FROM facilitydetail";
      $result = mysqli_query($conn, $sql);
    
$result=$conn->query($sql);

?>
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">
<link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<style>
    body{ font: 14px sans-serif; }
    .wrapper{ width: 360px; padding: 20px; }
    @media screen and (max-width: 500px) {
      .menu-link{visibility: hidden;
              display: none;}
    .main-nav{visibility: hidden;
              display: none;}
    #a{margin-left: -150px;}
    #b{font: 10px sans-serif; margin-top: 30px;}
          /* i{ display: none;}; */
    }
</style>
<title>Dormitory Management System</title>

<!-- Bootstrap core CSS -->
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<!-- Additional CSS Files -->
<link rel="stylesheet" href="assets/css/fontawesome.css">
<link rel="stylesheet" href="assets/css/templatemo-grad-school.css">
<link rel="stylesheet" href="assets/css/owl.css">
<link rel="stylesheet" href="assets/css/lightbox.css">

</head>

<body>
<!--header-->
<header class="main-header clearfix" role="header">
    <div class="logo">
      <a href="homePage.php"><em>Dorm</em> Sys</a>
    </div>
    <a href="#menu" class="menu-link"><i class="fa fa-bars"></i></a>
    <nav id="menu" class="main-nav" role="navigation">
      <ul class="main-menu">
        <!-- <li><a href="index.php">Home</a></li> -->
          <li><a href="accountPage.php">Account</a>
          <!-- <ul class="sub-menu">
            <li><a href="#section2">Register</a></li>
            <li><a href="#section3">Login</a></li>
            <li><a href="#section3">Account Details</a></li>
            <li><a href="#section4">Generate User Listing</a></li>
          </ul> -->
        </li>
        <li><a href="facilityPage.php">Facility</a>
        <li><a href="roomPage.php">Room</a></li>
        <li><a href="keyPage.php">Key</a></li>
        <li><a href="cardPage.php">Card</a></li>
        <li><a href="announcementPage.php">Announcement</a></li>
        <li><a href="feedbackPage.php">Feedback</a></li>
        <li><a href="faultPage.php">Fault</a></li>
        <li><a href="reportPage.php">Report</a></li>
        <li><a href="logout.php" style="background-color:red;">Log Out</a></li>
        <!-- <li><a href="#section5">Video</a></li> -->
      </ul>
    </nav>
  </header>

<br>
<br>
<br>
<br>
<h2 id="a" style="padding-left:200px; padding-top:50px; color:white;"><strong>View Facility</strong></h2>
<br><br>
<body style="background-image:url(assets/images/banner.jpg);">

<div class="container">
	    <div class="row">
			
		    <table id="b" class="table table-hover table-striped">
		        <thead>
		        <tr class="thead-dark">
		            <th style="color:white;">ID</th>
		            <th style="color:white;">Name</th>
		            <th style="color:white;">Type</th>
                <th style="color:white;">Image</th>
                <th style="color:white;">Status</th>
		        </tr>
		    </thead>
		        <tbody>
		            <?php
	if($result->num_rows > 0){
		while($row=$result->fetch_assoc()){
            $ID=$row['ID'];
            $name=$row['name'];  
            $type=$row['type'];
            $image=$row['image'];
            $status=$row['status'];
	//display result​
					?>
		            <tr>
		                <td style="color:white;"><?php echo $ID; ?></td>
		                <td style="color:white;"><?php echo $name;?></td>
                        <td style="color:white;"><?php echo $type;?></td>
                        <td style="color:white;"><?php 	echo "<div id='img_div'>";
echo '<img src="images/'. $row['image'] .'" style="width:200px; height:200px;" alt="" /><br />';
	echo "</div>"; ?></td>
                        <td style="color:white;"><?php echo $status; ?></td>
		            </tr>
					<?php

}//end while loop​
	
}//end if statement
					?>	        
		        </tbody>
		    </table>
	</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </body>
</html>