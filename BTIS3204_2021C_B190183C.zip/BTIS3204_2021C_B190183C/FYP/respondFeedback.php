<!doctype html>
<style>
#error{
    width:92%;
    margin:0px auto;
    padding:10px;
    border:1px solid #a94442;
    background:#f2dede;
    border-radius:5px;
    text-align:left;

}
.variablecolor{
color:red;}
</style>
<?php
        session_start();
        $errors = array();
        $id =  $_SESSION['username'];
  include('config.php');
  

  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "fyp";

  $conn = new mysqli($servername, $username, $password, $dbname);
  $ID = $_GET['id'];

    // Check connection
    if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
      }
    
      $sql = "SELECT * FROM feedbackdetail WHERE id ='$ID'";
      $result = mysqli_query($conn, $sql);
    
      
      $result=$conn->query($sql);

      if(isset($_POST['submit'])){
        $username=$_POST['username'];
        $respondID=$_POST['respondID'];
        $respondName=$_POST['respondName'];
        $topic=$_POST['topic'];  
        $message=$_POST['message'];
          // if($res_id->num_rows > 0){
          // 	array_push($errors, "Id has already been taken");
          // }
          // else{
                //step5,
        $sql="insert into feedbackdetail(username,respondID,respondName,topic,message) values('$username','$respondID','$respondName','$topic','$message')";
        //step6
        $result=$conn->query($sql);  
        //last step
        $conn->close();
          }
?>
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">
<link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<style>
    body{ font: 14px sans-serif; }
    .wrapper{ width: 360px; padding: 20px; }
    @media screen and (max-width: 500px) {
      .menu-link{visibility: hidden;
              display: none;}
    .main-nav{visibility: hidden;
              display: none;}
    #a{margin-top: -50px; margin-left: -150px;}
    textarea{width: 425px;}
          /* i{ display: none;}; */
    }
</style>
<title>Dormitory Management System</title>

<!-- Bootstrap core CSS -->
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<!-- Additional CSS Files -->
<link rel="stylesheet" href="assets/css/fontawesome.css">
<link rel="stylesheet" href="assets/css/templatemo-grad-school.css">
<link rel="stylesheet" href="assets/css/owl.css">
<link rel="stylesheet" href="assets/css/lightbox.css">
<script>
    function Confirm() {
      return confirm("Are you sure to submit with these information?");
    }
    function validateForm() {
        alert("Feedback Respond Successfully.");
        return true;
    }
    </script>
</head>

<body>
<!--header-->
<header class="main-header clearfix" role="header">
    <div class="logo">
      <a href="homePage.php"><em>Dorm</em> Sys</a>
    </div>
    <a href="#menu" class="menu-link"><i class="fa fa-bars"></i></a>
    <nav id="menu" class="main-nav" role="navigation">
      <ul class="main-menu">
        <!-- <li><a href="index.php">Home</a></li> -->
          <li><a href="accountPage.php">Account</a>
          <!-- <ul class="sub-menu">
            <li><a href="#section2">Register</a></li>
            <li><a href="#section3">Login</a></li>
            <li><a href="#section3">Account Details</a></li>
            <li><a href="#section4">Generate User Listing</a></li>
          </ul> -->
        </li>
        <li><a href="facilityPage.php">Facility</a>
        <li><a href="roomPage.php">Room</a></li>
        <li><a href="keyPage.php">Key</a></li>
        <li><a href="cardPage.php">Card</a></li>
        <li><a href="announcementPage.php">Announcement</a></li>
        <li><a href="feedbackPage.php">Feedback</a></li>
        <li><a href="faultPage.php">Fault</a></li>
        <li><a href="reportPage.php">Report</a></li>
        <li><a href="logout.php" style="background-color:red;">Log Out</a></li>
        <!-- <li><a href="#section5">Video</a></li> -->
      </ul>
    </nav>
  </header>

<br>
<br>
<br>
<br>
<h2 id="a" style="padding-left:200px; padding-top:50px; color:white;"><strong>Respond Feedback</strong></h2>
<br><br>
<body style="background-image:url(assets/images/banner.jpg);">

<div class="container">
	    <div class="row">
			
		    <table class="table table-hover table-striped">
		        <thead>
		        <tr class="thead-dark">
                    <th style="color:white;">ID</th>
		            <th style="color:white;">Username</th>
		            <th style="color:white;">Topic</th>
                    <th style="color:white;">Message</th>
		        </tr>
		    </thead>
		        <tbody>
		            <?php
	if($result->num_rows > 0){
		while($row=$result->fetch_assoc()){
            $ID=$row['ID'];
            $username=$row['username'];
            $topic=$row['topic'];  
            $message=$row['message'];
	//display result​
					?>
		            <tr>
                        <td style="color:white;"><?php echo $ID; ?></td>
		                <td style="color:white;"><?php echo $username; ?></td>
		                <td style="color:white;"><?php echo $topic;?></td>
                        <td style="color:white;"><?php echo $message; ?></td>
		            </tr>
					<?php

}//end while loop​
	
}//end if statement
					?>	        
		        </tbody>
		    </table>
	</div>

    <div class="container">
    <form method = "post" action="respondFeedback.php"enctype="multipart/form-data"  onsubmit="return validateForm()">
        <!-- <div class="form-group">
            <label for="ID"><h5 style="color:white;">ID</h5></label>
            <input type="text" class="form-control" id="ID" name="ID">
        </div> -->
        <div class="form-group">
            <!-- <label for="username"><h5 style="color:white;">Username</h5></label></br> -->
            <input type="hidden" class="form-control" name="username" value="<?php echo $id; ?>"readonly="readonly">
            </br>
          </div>
          <div class="form-group">
            <!-- <label for="respondID"><h5 style="color:white;">Respond to ID</h5></label></br> -->
            <input type="hidden" class="form-control" name="respondID" value="<?php echo $ID; ?>"readonly="readonly">
            </br>
          </div>
          <div class="form-group">
            <!-- <label for="respondName"><h5 style="color:white;">Respond to Username</h5></label></br> -->
            <input type="hidden" class="form-control" name="respondName" value="<?php echo $username; ?>"readonly="readonly">
            </br>
          </div>
          <div class="form-group">
            <!-- <label for="topic"><h5 style="color:white;">Topic</h5></label></br> -->
            <input type="hidden" class="form-control" name="topic" value="<?php echo $topic; ?>"readonly="readonly">
            </br>
          </div>
        <div class="form-group" style="margin-top:-150px;">
        <label for="name"><h5 style="color:white;">Respond Message</h5></label>
            </br>
            <textarea name="message" rows="10" cols="123"></textarea>
        <!-- <div class="form-group">
            <label for="keyID"><h5 style="color:white;">Key ID</h5></label>
            <input type="text" class="form-control" id="keyID" name="keyID">
        </div>
        <div class="form-group">
            <label for="cardID"><h5 style="color:white;">Card ID</h5></label>
            <input type="text" class="form-control" id="cardID" name="cardID">
        </div> -->
        <!-- <div class="form-group">
            <label for="feedbackID"><h5 style="color:white;">Feedback ID</h5></label>
            <input type="text" class="form-control" id="feedbackID" name="feedbackID">
        </div>
        <div class="form-group">
            <label for="faultReportID"><h5 style="color:white;">Fault Report ID</h5></label>
            <input type="text" class="form-control" id="faultReportID" name="faultReportID">
        </div> -->
        <!-- <div class="form-group">
            <label for="status"><h5 style="color:white;">Status</h5></label>
            <input type="text" class="form-control" id="status" name="status">
        </div>
        <br> -->
        <br>
            <button style="margin-top:30px" type="submit" class="btn btn-primary"name="submit" onclick="return Confirm()">Submit</button>
        </div>
        <br>
        <br>
    </form>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </body>
</html>