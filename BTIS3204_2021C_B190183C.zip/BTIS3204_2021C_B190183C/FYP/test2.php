<?php
  $errors = array();
  include('config.php');
  
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "fyp";

  $conn = new mysqli($servername, $username, $password, $dbname);
  if($conn->connect_error) die ("Fatal Error");
   
    $ID = $_GET['ID'];
    $dateOfStay = $_GET['dateOfStay'];

    $query = "UPDATE userdetail SET dateOfStay='$dateOfStay' WHERE ID='$ID'";
    $conn->query($query);
//echo $query;
//echo "Hello";

?>