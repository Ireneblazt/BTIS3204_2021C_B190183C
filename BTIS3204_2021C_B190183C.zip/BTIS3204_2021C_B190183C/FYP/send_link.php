<!doctype html>
<style>
#error{
    width:92%;
    margin:0px auto;
    padding:10px;
    border:1px solid #a94442;
    background:#f2dede;
    border-radius:5px;
    text-align:left;

}
.variablecolor{
color:red;}
</style>
<?php
  $errors = array();
  include('config.php');

  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "fyp";

  $conn = new mysqli($servername, $username, $password, $dbname);
        
    
  if(isset($_POST['submit'])){
  $ID=$_POST['ID'];
  $name=$_POST['name'];
  $dateOfStay=$_POST['dateOfStay'];  
  $roomID=$_POST['roomID'];
  $keyID=$_POST['keyID'];
  $cardID=$_POST['cardID'];
  $status=$_POST['status'];
	// if($res_id->num_rows > 0){
	// 	array_push($errors, "Id has already been taken");
	// }
	// else{
		  //step5,
  $sql="insert into userdetail(ID,name,dateOfStay,roomID,keyID,cardID,status) values('$ID','$name','$dateOfStay','$roomID','$keyID','$cardID','$status')";
  //step6
  $result=$conn->query($sql);  
  //last step
  $conn->close();
	}

  {$conn = new mysqli($servername, $username, $password, $dbname);
    $query="SELECT * FROM `roomdetail` ORDER BY `ID` DESC";
    $stmt = mysqli_query($conn,$query);
    $count = $stmt->num_rows;
    $conn->close();}

  {$conn = new mysqli($servername, $username, $password, $dbname);
    $query1="SELECT * FROM `keydetail` ORDER BY `ID` DESC";
    $stmt1 = mysqli_query($conn,$query1);
    $count1 = $stmt1->num_rows;
    $conn->close();}

  {$conn = new mysqli($servername, $username, $password, $dbname);
    $query2="SELECT * FROM `carddetail` ORDER BY `ID` DESC";
    $stmt2 = mysqli_query($conn,$query2);
    $count2 = $stmt2->num_rows;
    $conn->close();}
  
    {$conn = new mysqli($servername, $username, $password, $dbname);
    $query3="SELECT * FROM `username` ORDER BY `ID` DESC";
    $stmt3 = mysqli_query($conn,$query3);
    $count3 = $stmt3->num_rows;
    $conn->close();}
?>
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">
<link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<style>
    body{ font: 14px sans-serif; }
    .wrapper{ width: 360px; padding: 20px; }
</style>
<title>Dormitory Management System</title>

<!-- Bootstrap core CSS -->
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<!-- Additional CSS Files -->
<link rel="stylesheet" href="assets/css/fontawesome.css">
<link rel="stylesheet" href="assets/css/templatemo-grad-school.css">
<link rel="stylesheet" href="assets/css/owl.css">
<link rel="stylesheet" href="assets/css/lightbox.css">
<script>
    function Confirm() {
      return confirm("Are you sure to submit with these information?");
    }
    function validateForm() {
        alert("Account Inserted Successfully.");
        return true;
    }
    </script>
</head>

<body>
<!--header-->
<header class="main-header clearfix" role="header">
    <div class="logo">
    <a href="#"><em>Dorm</em> Sys</a>
    </div>
    <a href="#menu" class="menu-link"><i class="fa fa-bars"></i></a>
    <nav id="menu" class="main-nav" role="navigation">
      <ul class="main-menu">
        <!-- <li><a href="index.php">Home</a></li> -->
          <li><a href="accountPage.php">Account</a>
          <!-- <ul class="sub-menu">
            <li><a href="#section2">Register</a></li>
            <li><a href="#section3">Login</a></li>
            <li><a href="#section3">Account Details</a></li>
            <li><a href="#section4">Generate User Listing</a></li>
          </ul> -->
        </li>
        <li><a href="facilityPage.php">Facility</a>
        <li><a href="roomPage.php">Room</a></li>
        <li><a href="keyPage.php">Key</a></li>
        <li><a href="cardPage.php">Card</a></li>
        <li><a href="announcementPage.php">Announcement</a></li>
        <li><a href="feedbackPage.php">Feedback</a></li>
        <li><a href="faultPage.php">Fault</a></li>
        <li><a href="reportPage.php">Report</a></li>
        <li><a href="logout.php" style="background-color:red;">Log Out</a></li>
        <!-- <li><a href="#section5">Video</a></li> -->
      </ul>
    </nav>
  </header>

<br>
<br>
<br>
<br>
<h2 style="padding-left:200px; padding-top:50px; color:white;"><strong>Insert Account</strong></h2>
<br><br>
<body style="background-image:url(assets/images/banner.jpg);">

<div class="container">
<?php
if(isset($_POST['submit_email']) && $_POST['email'])
{
  mysql_connect('localhost','root','');
  mysql_select_db('FYP');
  $select=mysql_query("select email,password from username where email='$email'");
  if(mysql_num_rows($select)==1)
  {
    while($row=mysql_fetch_array($select))
    {
      $email=md5($row['email']);
      $pass=md5($row['password']);
    }
    $link="<a href='www.samplewebsite.com/reset.php?key=".$email."&reset=".$pass."'>Click To Reset password</a>";
    require_once('phpmail/PHPMailerAutoload.php');
    $mail = new PHPMailer();
    $mail->CharSet =  "utf-8";
    $mail->IsSMTP();
    // enable SMTP authentication
    $mail->SMTPAuth = true;                  
    // GMAIL username
    $mail->Username = "your_email_id@gmail.com";
    // GMAIL password
    $mail->Password = "your_gmail_password";
    $mail->SMTPSecure = "ssl";  
    // sets GMAIL as the SMTP server
    $mail->Host = "smtp.gmail.com";
    // set the SMTP port for the GMAIL server
    $mail->Port = "465";
    $mail->From='your_gmail_id@gmail.com';
    $mail->FromName='your_name';
    $mail->AddAddress('reciever_email_id', 'reciever_name');
    $mail->Subject  =  'Reset Password';
    $mail->IsHTML(true);
    $mail->Body    = 'Click On This Link to Reset Password '.$pass.'';
    if($mail->Send())
    {
      echo "Check Your Email and Click on the link sent to your email";
    }
    else
    {
      echo "Mail Error - >".$mail->ErrorInfo;
    }
  }	
}
?>
    </div>

    <footer>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <p><i class="fa fa-copyright"></i> Dormitory Management System<a href="#" rel="sponsored" target="_parent"></a></p>
        </div>
      </div>
    </div>
  </footer>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </body>
</html>