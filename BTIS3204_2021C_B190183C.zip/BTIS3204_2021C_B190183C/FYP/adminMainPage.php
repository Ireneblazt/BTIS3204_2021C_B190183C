<!DOCTYPE html>
<html>
    <head>
        <title>Page Title</title>
        <link rel="stylesheet" href="style.css">
    </head>

    <body>
        <div class="wrapper">
        <ul>
            <li>Main Page</li>
            <li>Account
                <ul>
                    <li>Account Details</li>
                    <li>Search Account</li>
                    <li>User Listing</li>
                </ul>
            </li>
            <li>Facility</li>
            <li>Room</li>
            <li>Key</li>
            <li>Card</li>
            <li>Announcement</li>
            <li>Feedback</li>
            <li>Fault Report</li>
            <li>Report</li>
            <!-- <li>Services
                <ul>
                    <li>Marketing</li>
                    <li>Design
                        <ul>
                            <li>Web</li>
                            <li>Graphics</li>
                            <li>Interior</li>
                        </ul>
                    </li>
                    <li>Branding</li>
                </ul>
            </li> -->
            <li>Login</li>
            </ul>
        </div>
    </body>
</html>
