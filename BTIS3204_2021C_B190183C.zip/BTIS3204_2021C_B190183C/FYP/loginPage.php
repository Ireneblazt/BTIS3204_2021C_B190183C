<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: accountPage.php");
    exit;
}
 
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = $login_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter username.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT id, username, password FROM username WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = $username;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;                            
                            
                            if($username=="admin"){
                              $_SESSION['username'] = $username;
                              header('location:accountPage.php');//redirect to admin page for admin
                              }
                              else{
                              header('location:userAccountPage.php');//redirect to home page for user
                          }

                        } else{
                            // Password is not valid, display a generic error message
                            $login_err = "Invalid username or password.";
                        }
                    }
                } else{
                    // Username doesn't exist, display a generic error message
                    $login_err = "Invalid username or password.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif; }
        .wrapper{ height: 734px; width: 360px; padding: 20px; margin-left:530px;}
        
        @media screen and (max-width: 500px) {
          .wrapper{ height: 694px; width: 360px; padding: 20px; margin-left:20px; margin-top:35px;}
        }
    </style>
    <title>Dormitory Management System</title>
    
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-grad-school.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/lightbox.css">

  </head>

<body>
  <!--header-->
  <header class="main-header clearfix" role="header">
    <div class="logo">
      <a href="#"><em>Dorm</em> Sys</a>
    </div>
    <a href="#menu" class="menu-link"><i class="fa fa-bars"></i></a>
    <!-- <nav id="menu" class="main-nav" role="navigation" style="overflow:hidden;">
      <ul class="main-menu">
        <li><a href="loginPage.php">Login</a></li> -->
        <!-- <li><a href="registrationPage.php">Register</a></li> -->
        <!-- <li class="has-submenu"><a href="#section2">Account</a>
          <ul class="sub-menu">
            <li><a href="#section2">Register</a></li>
            <li><a href="#section3">Login</a></li>
            <li><a href="#section3">Account Details</a></li>
            <li><a href="#section4">Generate User Listing</a></li>
          </ul>
        </li>
        <li><a href="#section4">Room</a></li>
        <li><a href="#section6">Key</a></li>
        <li><a href="#section6">Card</a></li>
        <li><a href="#section6">Announcement</a></li>
        <li><a href="#section6">Feedback</a></li>
        <li><a href="#section6">Fault</a></li>
        <li><a href="#section6">Report</a></li> -->
        <!-- <li><a href="#section5">Video</a></li> -->
      <!-- </ul>
    </nav>
  </header> -->
  
  <section class="section contact" data-section="section6" style="margin-top: -100px;">
  <!-- style="margin-left:530px;" -->
  <div class="wrapper">
        <h2>Login</h2>
        </br>
        <p>Please fill in your credentials to login.</p>

        <?php 
        if(!empty($login_err)){
            echo '<div class="alert alert-danger">' . $login_err . '</div>';
        }        
        ?>

          <div class="caption">
              <h2 style= "color:yellow; margin-top:53.9px; margin-left:125px;">Login Page</h2></br>
          </div>

        <form style="margin-left:60px" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label style="color:white">Username</label>
                <input type="text" name="username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>    
            <div class="form-group">
                <label style="color:white">Password</label>
                <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Login">
            </div>
            <!-- <p style="color:white">Don't have an account? <a href="registrationPage.php">Sign up now</a></p> -->
            <p style="color:white"><a href="resetPassword.php">Click here to reset password</a></p>
            <!-- <p style="color:white">Help and Support on the right button</p> -->
        </form>
        <script src="https://apps.elfsight.com/p/platform.js" defer></script>
        <div class="elfsight-app-182e6d60-95d1-40e3-a01e-43adfa8b0cad"></div>
    </div>
  </section>

  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script src="assets/js/isotope.min.js"></script>
    <script src="assets/js/owl-carousel.js"></script>
    <script src="assets/js/lightbox.js"></script>
    <script src="assets/js/tabs.js"></script>
    <script src="assets/js/video.js"></script>
    <script src="assets/js/slick-slider.js"></script>
    <script src="assets/js/custom.js"></script>
    <script>
        //according to loftblog tut
        $('.nav li:first').addClass('active');

        var showSection = function showSection(section, isAnimate) {
          var
          direction = section.replace(/#/, ''),
          reqSection = $('.section').filter('[data-section="' + direction + '"]'),
          reqSectionPos = reqSection.offset().top - 0;

          if (isAnimate) {
            $('body, html').animate({
              scrollTop: reqSectionPos },
            800);
          } else {
            $('body, html').scrollTop(reqSectionPos);
          }

        };

        var checkSection = function checkSection() {
          $('.section').each(function () {
            var
            $this = $(this),
            topEdge = $this.offset().top - 80,
            bottomEdge = topEdge + $this.height(),
            wScroll = $(window).scrollTop();
            if (topEdge < wScroll && bottomEdge > wScroll) {
              var
              currentId = $this.data('section'),
              reqLink = $('a').filter('[href*=\\#' + currentId + ']');
              reqLink.closest('li').addClass('active').
              siblings().removeClass('active');
            }
          });
        };

        // $('.main-menu, .scroll-to-section').on('click', 'a', function (e) {
        //   if($(e.target).hasClass('external')) {
        //     return;
        //   }
        //   e.preventDefault();
        //   $('#menu').removeClass('active');
        //   showSection($(this).attr('href'), true);
        // });

        $(window).scroll(function () {
          checkSection();
        });
    </script>
</body>
</html>